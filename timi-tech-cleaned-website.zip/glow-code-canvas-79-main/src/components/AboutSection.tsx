
import React from 'react';
import { Code, Users, Briefcase } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            Passionate developer with a love for creating amazing digital experiences
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              Welcome to my digital space! I'm a freelance web developer with over 3 years of experience 
              crafting beautiful, functional websites and web applications. My journey began with a curiosity 
              about how websites work, and it has evolved into a passion for creating digital solutions that 
              make a real impact.
            </p>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              I specialize in modern web technologies and love bringing ideas to life through clean code 
              and intuitive design. Whether you need a stunning landing page, a complex web application, 
              or anything in between, I'm here to help make your vision a reality.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-8">
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <Code className="mx-auto mb-4 text-blue-600 dark:text-blue-400" size={32} />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Clean Code</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Writing maintainable, scalable code</p>
              </div>
              
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <Users className="mx-auto mb-4 text-blue-600 dark:text-blue-400" size={32} />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">User-Focused</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Designing with users in mind</p>
              </div>
              
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <Briefcase className="mx-auto mb-4 text-blue-600 dark:text-blue-400" size={32} />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Professional</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Delivering quality results on time</p>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="relative">
              <div className="w-80 h-80 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full p-1">
                <div className="w-full h-full bg-white dark:bg-gray-900 rounded-full flex items-center justify-center">
                  <img
                    src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                    alt="Profile"
                    className="w-72 h-72 object-cover rounded-full"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
