
import React from 'react';
import { Code, Image, Briefcase, Users } from 'lucide-react';

const ServicesSection: React.FC = () => {
  const services = [
    {
      icon: <Code size={40} />,
      title: 'Web Development',
      description: 'Custom websites and web applications built with modern technologies like React, TypeScript, and Node.js.',
      features: ['Responsive design', 'SEO optimization', 'Performance optimization', 'Cross-browser compatibility'],
    },
    {
      icon: <Image size={40} />,
      title: 'Landing Pages',
      description: 'High-converting landing pages designed to capture leads and drive conversions for your business.',
      features: ['Mobile-first design', 'Fast loading times', 'A/B testing ready', 'Analytics integration'],
    },
    {
      icon: <Briefcase size={40} />,
      title: 'E-commerce Solutions',
      description: 'Complete e-commerce platforms with payment processing, inventory management, and admin dashboards.',
      features: ['Payment gateway integration', 'Inventory management', 'Order tracking', 'Admin dashboard'],
    },
    {
      icon: <Users size={40} />,
      title: 'Dashboard Systems',
      description: 'Custom dashboard and admin panels with real-time data visualization and user management.',
      features: ['Real-time updates', 'Data visualization', 'User management', 'Role-based access'],
    },
  ];

  return (
    <section id="services" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            My Services
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            Comprehensive web development solutions for your business needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-900 p-8 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="text-blue-600 dark:text-blue-400 mb-4">
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                {service.title}
              </h3>
              
              <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-center text-gray-700 dark:text-gray-300"
                  >
                    <div className="w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="https://wa.me/1234567890"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            Get A Quote
          </a>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
